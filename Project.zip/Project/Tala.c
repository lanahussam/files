#define SERVO_1_PIN 0x02  // RC1 (Servo 1 - Software PWM)
#define SERVO_2_PIN 0x10  // RC4 (Servo 2 - Software PWM)
#define SERVO_3_PIN 0x20  // RC5 (Servo 3 - Software PWM)
#define SERVO_4_PIN 0x40  // RC6 (Servo 4 - Timer1 CCP)


#define BUTTON_1_PIN 0x01 // RB0
#define BUTTON_2_PIN 0x02 // RB1
#define BUTTON_3_PIN 0x04 // RB2
#define LED1 0x10 //RB4
#define LED2 0x20 //RB5
#define LED3 0x40 //RB6
#define DC_MOTOR_IN1_PIN 0x04 // RD2
#define DC_MOTOR_IN2_PIN 0x08 // RD3
#define DC_MOTOR_ENABLE_PIN 0x04 // RC2 (CCP1 for PWM)

#define SONAR_TRIGGER_PIN 0x80  // RD7 (Trigger)
#define SONAR_ECHO_PIN 0x40     // RD6 (Echo)

#define BUZZER_PIN 0x08  // RB3 (Buzzer)
#define LED_PIN 0x80 // RB7


#define MIN_DUTY_CYCLE 50
#define MAX_DUTY_CYCLE 255

// Global variables
unsigned long Distance;      // Calculated distance in cm
unsigned int i,j;
unsigned int adc_value;
unsigned int  overflow_count =0;
unsigned int Degree_increment = 45;
 unsigned int currentPosition=0;
// Function for microsecond delay using a for loop
void delay_us(unsigned int usCnt) {
    for (i = 0; i < usCnt; i++) {
        asm nop;  // 1 microsecond delay per iteration
    }
}

// Function for millisecond delay
void delay_ms(unsigned int msCnt) {
    for (i = 0; i < msCnt; i++) {
        delay_us(1000); // Delay 1000 microseconds (1 millisecond)
    }
}
 interrupt(){
        if(TMR0IF){
          overflow_count++;
          if(overflow_count>= 390){
              //servo in default position
              overflow_count=0;
        }
        TMR0= 156;
       INTCON &= 0xFB; // TMR0IF = 0 clearing the flag
        }
 }


void adc_init() {
    ADCON0 = 0x01; // ADC enabled, select channel AN0
    ADCON1 = 0x0E; // Configure AN0 as analog input
}

unsigned int adc_read() {
    ADCON0 |= 0x04; // Start ADC conversion
    while (ADCON0 & 0x04); // Wait for conversion to complete
    return (ADRESH << 8) | ADRESL; // Return result
}

// Software PWM function
void software_pwm(unsigned char pin, unsigned int angle) {
    unsigned int duty_cycle = ((angle * (MAX_DUTY_CYCLE - MIN_DUTY_CYCLE)) / 360) + MIN_DUTY_CYCLE;
    unsigned int on_time = duty_cycle;
    unsigned int off_time = 10000 - on_time;

    PORTC |= pin;
    for (i = 0; i < on_time; i++) {
        asm nop;
    }

    PORTC &= ~pin;
    for (i = 0; i < off_time; i++) {
        asm nop;
    }
}

// Timer1-based PWM for SERVO_4
void timer1_pwm(unsigned int angle) {
    unsigned int duty_cycle = ((angle * (MAX_DUTY_CYCLE - MIN_DUTY_CYCLE)) / 360) + MIN_DUTY_CYCLE;
    unsigned int pulse_width = duty_cycle;

    TMR1H = 0;
    TMR1L = 0;

    while (pulse_width--) {
        asm nop;
    }
}

  void init_pwm(){
  T2CON= 0x07; //Timer2 on with prescaler 16
  PR2= 250;
  CCP1CON =0x0C; //CCP1 in pwm mode
  CCPR1L = 125; //50% duty cycle
 TRISC = TRISC & 0x04; //RC2 is an output
 }

  void rotate_motor_clockwise() {
    PORTD |=0x04;  // Clockwise direction
    PORTD &= 0x08;
}

void rotate_motor_counterclockwise() {
    PORTD &= 0x04;  // Counterclockwise direction
    PORTD |= 0x08;
}

void disable_pwm() {
    CCPR1L = 0; // Set duty cycle to 0%
}
void enable_pwm() {
    CCP1CON &= 0xF3; // Clear DC1B1 and 0
    CCPR1L = 125;         // 50% duty cycle
}

// Ultrasonic sensor functions

void init_sonar(void) {
    TMR1H = 0;
    TMR1L = 0;
    Distance = 0;

    PORTD &= ~SONAR_TRIGGER_PIN;
    INTCON |= 0xC0;
    PIE1 |= 0x01;
    T1CON = 0x18;
}

void read_sonar(void) {
    unsigned int time;

    TMR1H = 0;
    TMR1L = 0;

    PORTD |= SONAR_TRIGGER_PIN;
    delay_us(10);
    PORTD &= ~SONAR_TRIGGER_PIN;

    while (!(PORTD & SONAR_ECHO_PIN));
    T1CON |= 0x01;

    while (PORTD & SONAR_ECHO_PIN);
    T1CON &= ~0x01;

    time = ((TMR1H << 8) | TMR1L);
    Distance = ((time * 34) / 1000) / 2;

    // Check distance and trigger buzzer if too close
    if (Distance < 10) {  // Threshold distance in cm
        PORTB |= BUZZER_PIN;  // Turn on buzzer

        // Reset hand to default position
        software_pwm(SERVO_1_PIN, 0);
        software_pwm(SERVO_2_PIN, 0);
        software_pwm(SERVO_3_PIN, 0);
        timer1_pwm(0);

        delay_ms(500);  // Keep buzzer on for 500ms
        PORTB &= ~BUZZER_PIN;  // Turn off buzzer
    }
}

// Handle servo movements
void handle_servo_combinations(unsigned char button) {
    switch (button) {
        case BUTTON_1_PIN:
        //i  love you
            software_pwm(SERVO_1_PIN, 45);  //index
            software_pwm(SERVO_2_PIN, 90);    //middle
            software_pwm(SERVO_3_PIN, 135);   //pinky
            timer1_pwm(90);  //ring
            break;
        case BUTTON_2_PIN:
        //no
            software_pwm(SERVO_1_PIN, 90);
            software_pwm(SERVO_2_PIN, 45);
            software_pwm(SERVO_3_PIN, 90);
            timer1_pwm(45);

            break;
        case BUTTON_3_PIN:
        //goodbye
            software_pwm(SERVO_1_PIN, 135);
            software_pwm(SERVO_2_PIN, 135);
            software_pwm(SERVO_3_PIN, 90);
            timer1_pwm(45);

            break;
        default:
            break;
    }
}

void delay_500ms(){
  for( i=0;i<500;i++){
   for(j=0;j<1000;j++){
    //empty loop
   }
  } //for fosc =4Mhz (1000*500*2)*10^-6(for incrementing)
 }

// Main function
void main() {
    TRISB = 0x07;
    TRISC = 0x00;
    TRISD = 0x03;
    TRISA = 0x01;
    PORTB &= ~(0xF8);
    init_pwm();
    adc_init();


    //init_sonar();

    while (1) {
        if (!(PORTB & BUTTON_1_PIN)) {
        PORTB |= 0x10;

            handle_servo_combinations(BUTTON_1_PIN);
             delay_ms(500);
            PORTB &= ~(0x10);
        } else if (!(PORTB & BUTTON_2_PIN)) {
        PORTB |=0x20;

            handle_servo_combinations(BUTTON_2_PIN);
             delay_ms(500);
            PORTB &= ~(0x20);
        } else if (!(PORTB & BUTTON_3_PIN)) {
        PORTB |=0x40;

           handle_servo_combinations(BUTTON_3_PIN);
              delay_ms(500);
           PORTB &= ~(0x40);
        }  // read_sonar();
            //DC:


     if((PORTD &0x01)==0){  //checking if RD0 is pressed
       //if position is less than 360
      PORTD |= 0x04; //setting IN1 as 1
      delay_500ms();
      //rotate by 45 using pwm
      }
      if(!(PORTD &0x02)){  //checking if RD1 is pressed
       //if position is less than 360
      PORTD |= 0x08; //setting IN1 as 1
      delay_500ms();
      //rotate by 45 using pwm
      }
      if ((PORTD &0x01)==0) {
            if (currentPosition < 360) {
                currentPosition += DEGREE_INCREMENT; // Increment by 45 degrees
                rotate_motor_clockwise();
                delay_500ms(); // Rotate for 0.5 seconds
                disable_pwm(); // Stop motor
                delay_500ms();
            }
        }

        // Check if button 2 is pressed (active low, rotate counterclockwise)
        if (!(PORTD&0x02)) {
            if (currentPosition > 0) {
                currentPosition -= DEGREE_INCREMENT; // Decrement by 45 degrees
                rotate_motor_counterclockwise();
                delay_500ms(); // Rotate for 0.5 seconds
                disable_pwm(); // Stop motor
                }
                }
       if((PORTD&0x10) == 0){ //limit switch activated (active low) RD4
       PORTD&= 0xF3; //stopping the motor
       disable_pwm();
       //servo in default
        software_pwm(SERVO_1_PIN, 0);
        software_pwm(SERVO_2_PIN, 0);
        software_pwm(SERVO_3_PIN, 0);
        timer1_pwm(0);
    }

        adc_value = adc_read();
        if (adc_value > 512) {
        PORTB |= LED_PIN; // Flex detected
         delay_ms(500);
        PORTB &= ~LED_PIN;



    }
}  }